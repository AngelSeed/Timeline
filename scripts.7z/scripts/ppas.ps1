## rev.2010071801
## author:Shilver'a Jagd
## license:CC BY-SA
##
## 引数でプリセット名を指定する
## 例) ppas.ps1 4層前半

$uri = "http://localhost:1337/place"
#$path = ".\settings.json"
$path = "$env:APPDATA\PaisleyPark\settings.json"
$Zone = $Args[0]

$data = Get-Content -Encoding UTF8 $path | ConvertFrom-Json
$Marker = $data.Presets |  where { $_.Name -eq $Zone } | select A,B,C,D,One,Two | ConvertTo-Json

#echo $Marker
Invoke-RestMethod -Uri $uri -Body $Marker -Method POST -ContentType "application/json"
