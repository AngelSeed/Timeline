## rev.2010071801
## author:Shilver'a Jagd
## license:CC BY-SA
##
## 引数で削除したいマーカー名を指定する
## 例) ppoff.ps1 D or ppoff.ps1 A D

$uri = "http://localhost:1337/place"
$Zone = @($Args[0],$Args[1],$Args[2],$Args[3],$Args[4],$Args[5])

switch ($Zone)
{
    "A" { $x = @{"A"   = @{Active="false" }} ; $stack += $x }
    "B" { $x = @{"B"   = @{Active="false" }} ; $stack += $x }
    "C" { $x = @{"C"   = @{Active="false" }} ; $stack += $x }
    "D" { $x = @{"D"   = @{Active="false" }} ; $stack += $x }
    "1" { $x = @{"One" = @{Active="false" }} ; $stack += $x }
    "2" { $x = @{"Two" = @{Active="false" }} ; $stack += $x }
}

$Marker = $stack | ConvertTo-Json
#echo $Marker
Invoke-RestMethod -Uri $uri -Body $Marker -Method POST -ContentType "application/json"
